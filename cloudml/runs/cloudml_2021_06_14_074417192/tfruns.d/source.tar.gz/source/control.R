library(cloudml)
library(keras)

getwd()

# Run this to test scripts

gs_path <- "gs://boreal-dock-314313/ada2021/"
#
gs_copy(source = "data",
        destination = gs_path,
        recursive = TRUE) # Copy from local directory to gcloud bucket


### TEST RUNS
########################################################

cloudml_train(
  file = "scripts/model_vgg16.R",
  master_type = "standard_gpu"
)

job_collect("cloudml_2021_06_08_221752886")
view_run("runs/cloudml_2021_06_08_221752886")


# Multi output model test

# cloudml_train(
#   file = "scripts/multi_output_model.R",
#   master_type = "standard_gpu"
# )

view_run("runs/cloudml_2021_06_08_164831387")


# Multi input model test (Biomass)

# cloudml_train(
#   file = "scripts/multi_inputs_model.R",
#   master_type = "standard_gpu"
# )

view_run("runs/cloudml_2021_06_08_165302792")

########################################################
#### TRAINING RUNS
########################################################
###
### MULTI-OUTPUT MODELS
########################################################

### Multi output model using VGG16 (pre-trained on the ImageNet dataset)


cloudml_train(
  file = "scripts/multi_out_vgg.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_11_115050512")
view_run("runs/cloudml_2021_06_11_115050512")

# Multi output model using Inception-V3 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/multi_out_inceptionv3.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_11_120717638")
view_run("runs/cloudml_2021_06_11_120717638")

### MULTI-INPUT MULTI-OUTPUT MODELS
########################################################

# Multi-input multi-output model using VGG-16 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/multi_inout_vgg16.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_11_120747317")
view_run("runs/cloudml_2021_06_11_120747317")

# Multi-input multi-output model using Inception-V3 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/multi_inout_inceptionv3.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_11_120819977")
view_run("runs/cloudml_2021_06_11_120819977")


########################################################
#### FINAL RUNS (TO SAVE MODELS)
########################################################
###
### MULTI-OUTPUT MODELS
########################################################

### Multi output model using VGG16 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/final_out_vgg16.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_09_092920310")
view_run("runs/cloudml_2021_06_09_092920310")

# Multi output model using Inception-V3 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/final_out_inceptionv3.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_09_092953844")
view_run("runs/cloudml_2021_06_09_092953844")

### MULTI-INPUT MULTI-OUTPUT MODELS
########################################################

# Multi-input multi-output model using VGG-16 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/final_inout_vgg16.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_09_093218210")
view_run("runs/cloudml_2021_06_09_093218210")

# Multi-input multi-output model using Inception-V3 (pre-trained on the ImageNet dataset)

cloudml_train(
  file = "scripts/final_inout_inceptionv3.R",
  master_type = "standard_p100"
)

job_collect("cloudml_2021_06_09_104327097")
view_run("runs/cloudml_2021_06_09_104327097")
